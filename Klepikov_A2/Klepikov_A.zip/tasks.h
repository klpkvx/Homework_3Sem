#include "student.h"

#ifndef TASKS_H_
#define TASKS_H_

int task01(Student *array, int n);
int task02(Student *array, int n);
int task03(Student *array, int n);
int task04(Student *array, int n);
int task05(Student *array, int len);
int task06(Student *array, int n, Student &x);
int task07(Student *array, int len, Student &x);
int task08(Student *array, int len, Student &x);
int task09(Student *array, int len, Student &x);
int task10(Student *array, int len, Student &x);
#endif